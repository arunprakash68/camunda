package com.bofa.visaprocess.delegate;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.runtime.SignalEventReceivedBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import static org.camunda.bpm.engine.variable.Variables.putValue;
@Component("accptedDelegate")
public class AcceptedDelegate implements JavaDelegate {

	@Autowired
	private RuntimeService runtimeService;
	@Override
	public void execute(DelegateExecution execution) throws Exception {

		System.out.println("accpted Delegate :: " + execution.getVariable("status"));
//		SignalEventReceivedBuilder builder =  runtimeService.createSignalEvent("signal_id");
//		builder.setVariables(putValue("test", "arunprakash.m@"));
//		builder.send();
		System.out.println("Signal send successfully");

	}

}
