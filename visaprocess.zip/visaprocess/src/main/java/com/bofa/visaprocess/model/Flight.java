package com.bofa.visaprocess.model;

import java.io.Serializable;
import java.time.LocalDate;

public class Flight implements Serializable{
	private String fromCity;
	private String toCity;
	private LocalDate dot;

	/**
	 * @return the fromCity
	 */
	public String getFromCity() {
		return fromCity;
	}

	/**
	 * @param fromCity the fromCity to set
	 */
	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}

	/**
	 * @return the toCity
	 */
	public String getToCity() {
		return toCity;
	}

	/**
	 * @param toCity the toCity to set
	 */
	public void setToCity(String toCity) {
		this.toCity = toCity;
	}

	/**
	 * @return the dot
	 */
	public LocalDate getDot() {
		return dot;
	}

	/**
	 * @param dot the dot to set
	 */
	public void setDot(LocalDate dot) {
		this.dot = dot;
	}

}
