package com.bofa.visaprocess;

import static org.camunda.bpm.engine.variable.Variables.putValue;

import java.util.Calendar;

import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngines;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.query.PeriodUnit;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.spring.boot.starter.annotation.EnableProcessApplication;
import org.camunda.bpm.spring.boot.starter.event.ProcessApplicationStartedEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.event.EventListener;

@SpringBootApplication
@EnableProcessApplication("visaprocess")
public class CamundaApplication {

	@Autowired
	private RuntimeService runtimeService;

	// @Autowired
	// private HistoryService historyService;

	public static final String PROCESS_DEFINITION_KEY = "generateRandom";

	public static void main(String... args) {
		SpringApplication.run(CamundaApplication.class, args);
	}

	@EventListener
	public void onStart(final ProcessApplicationStartedEvent startedEvent) {
//		ProcessInstance instance = runtimeService.startProcessInstanceByKey(PROCESS_DEFINITION_KEY,
//				putValue("email", "arunprakash.m@"));

		ProcessEngine engine = ProcessEngines.getDefaultProcessEngine();
		HistoryService historyService = engine.getHistoryService();
		System.out.println(historyService.toString());
		Calendar calendar = Calendar.getInstance();
		historyService.createHistoricProcessInstanceReport().startedBefore(calendar.getTime())
				.duration(PeriodUnit.MONTH);
	}
}
