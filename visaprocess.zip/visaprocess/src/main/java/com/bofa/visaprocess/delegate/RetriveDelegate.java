package com.bofa.visaprocess.delegate;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

import com.bofa.visaprocess.model.Flight;

@Component("retriveFlight")
public class RetriveDelegate implements JavaDelegate {

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		System.out.println("Retrive Delegate");

		String fromCity = execution.getVariable("fromCity").toString();

		String toCity = execution.getVariable("toCity").toString();

		Date date = (Date) execution.getVariable("travelDate");
		LocalDate localDate = Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDate();

		List<Flight> flights = getAllFlights().stream()
				.filter(x -> x.getFromCity().equalsIgnoreCase(fromCity) && x.getToCity().equalsIgnoreCase(toCity))
				.collect(Collectors.toList());
		execution.setVariable("availableFlightsCount", flights.size());

	}

	private List<Flight> getAllFlights() {

		List<Flight> flights = new ArrayList<Flight>();

		for (int i = 0; i <= 10; i++) {
			Flight flight = new Flight();
			flight.setFromCity("Chennai" + i);
			flight.setToCity("Bangalore" + i);
			flight.setDot(LocalDate.now());
			flights.add(flight);
		}

		return flights;
	}

}
