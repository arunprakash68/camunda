package com.bofa.java_external;

import java.util.Map;

import org.camunda.bpm.client.ExternalTaskClient;

public class PaymentExternalDelegate {

	public static void main(String[] args) {

		ExternalTaskClient client = ExternalTaskClient.create().baseUrl("http://localhost:7070/rest")
				.asyncResponseTimeout(10000) // long polling timeout
				.build();

		// subscribe to an external task topic as specified in the process
		client.subscribe("paymentExternal").lockDuration(1000)
				// the default lock duration is 20 seconds, but you can override this
				.handler((externalTask, externalTaskService) -> {
					// Put your business logic here

					System.out.println(externalTask.getAllVariables().keySet());
					System.out.println(externalTask.getAllVariables().values());
//					externalTask.getAllVariables().put("paymentStatus", true);
					Map<String, Object> map = externalTask.getAllVariables();
					map.put("paymentStatus", true);
					// Complete the task
					externalTaskService.complete(externalTask,map);
				}).open();
	}
}
